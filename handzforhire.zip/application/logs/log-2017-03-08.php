<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-08 06:56:25 --> Config Class Initialized
INFO - 2017-03-08 06:56:25 --> Hooks Class Initialized
DEBUG - 2017-03-08 06:56:25 --> UTF-8 Support Enabled
INFO - 2017-03-08 06:56:25 --> Utf8 Class Initialized
INFO - 2017-03-08 06:56:25 --> URI Class Initialized
DEBUG - 2017-03-08 06:56:25 --> No URI present. Default controller set.
INFO - 2017-03-08 06:56:25 --> Router Class Initialized
INFO - 2017-03-08 06:56:25 --> Output Class Initialized
INFO - 2017-03-08 06:56:25 --> Security Class Initialized
DEBUG - 2017-03-08 06:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 06:56:25 --> Input Class Initialized
INFO - 2017-03-08 06:56:25 --> Language Class Initialized
INFO - 2017-03-08 06:56:25 --> Loader Class Initialized
DEBUG - 2017-03-08 06:56:25 --> Config file loaded: C:\xampp\htdocs\plastics\application\config/layout.php
INFO - 2017-03-08 06:56:25 --> Helper loaded: url_helper
INFO - 2017-03-08 06:56:25 --> Helper loaded: file_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: layout_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: form_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: date_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: common_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: breadcrumb_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: admin_helper
INFO - 2017-03-08 06:56:26 --> Helper loaded: shipping_helper
INFO - 2017-03-08 06:56:26 --> Database Driver Class Initialized
DEBUG - 2017-03-08 06:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-08 06:56:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-08 06:56:26 --> Pagination Class Initialized
INFO - 2017-03-08 06:56:26 --> Language file loaded: language/english/service_messages_lang.php
INFO - 2017-03-08 06:56:26 --> Controller Class Initialized
INFO - 2017-03-08 06:56:26 --> Form Validation Class Initialized
DEBUG - 2017-03-08 06:56:26 --> Layout class already loaded. Second attempt ignored.
DEBUG - 2017-03-08 06:56:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-03-08 06:56:26 --> Model Class Initialized
INFO - 2017-03-08 06:56:26 --> File loaded: C:\xampp\htdocs\plastics\application\views\login/index.php
INFO - 2017-03-08 06:56:26 --> File loaded: C:\xampp\htdocs\plastics\application\views\layouts/frontend.php
INFO - 2017-03-08 06:56:26 --> Final output sent to browser
DEBUG - 2017-03-08 06:56:26 --> Total execution time: 1.8554
INFO - 2017-03-08 06:56:28 --> Config Class Initialized
INFO - 2017-03-08 06:56:28 --> Hooks Class Initialized
DEBUG - 2017-03-08 06:56:28 --> UTF-8 Support Enabled
INFO - 2017-03-08 06:56:28 --> Utf8 Class Initialized
INFO - 2017-03-08 06:56:28 --> URI Class Initialized
INFO - 2017-03-08 06:56:28 --> Router Class Initialized
INFO - 2017-03-08 06:56:28 --> Output Class Initialized
INFO - 2017-03-08 06:56:28 --> Security Class Initialized
DEBUG - 2017-03-08 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 06:56:28 --> Input Class Initialized
INFO - 2017-03-08 06:56:28 --> Language Class Initialized
ERROR - 2017-03-08 06:56:28 --> 404 Page Not Found: Faviconico/index
INFO - 2017-03-08 06:56:33 --> Config Class Initialized
INFO - 2017-03-08 06:56:33 --> Hooks Class Initialized
DEBUG - 2017-03-08 06:56:33 --> UTF-8 Support Enabled
INFO - 2017-03-08 06:56:33 --> Utf8 Class Initialized
INFO - 2017-03-08 06:56:33 --> URI Class Initialized
DEBUG - 2017-03-08 06:56:33 --> No URI present. Default controller set.
INFO - 2017-03-08 06:56:33 --> Router Class Initialized
INFO - 2017-03-08 06:56:33 --> Output Class Initialized
INFO - 2017-03-08 06:56:33 --> Security Class Initialized
DEBUG - 2017-03-08 06:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 06:56:33 --> Input Class Initialized
INFO - 2017-03-08 06:56:33 --> Language Class Initialized
INFO - 2017-03-08 06:56:33 --> Loader Class Initialized
DEBUG - 2017-03-08 06:56:33 --> Config file loaded: C:\xampp\htdocs\plastics\application\config/layout.php
INFO - 2017-03-08 06:56:33 --> Helper loaded: url_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: file_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: layout_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: form_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: date_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: common_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: breadcrumb_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: admin_helper
INFO - 2017-03-08 06:56:33 --> Helper loaded: shipping_helper
INFO - 2017-03-08 06:56:33 --> Database Driver Class Initialized
DEBUG - 2017-03-08 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-08 06:56:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-08 06:56:33 --> Pagination Class Initialized
INFO - 2017-03-08 06:56:34 --> Language file loaded: language/english/service_messages_lang.php
INFO - 2017-03-08 06:56:34 --> Controller Class Initialized
INFO - 2017-03-08 06:56:34 --> Form Validation Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Layout class already loaded. Second attempt ignored.
DEBUG - 2017-03-08 06:56:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-03-08 06:56:34 --> Model Class Initialized
INFO - 2017-03-08 06:56:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-08 06:56:34 --> Config Class Initialized
INFO - 2017-03-08 06:56:34 --> Hooks Class Initialized
DEBUG - 2017-03-08 06:56:34 --> UTF-8 Support Enabled
INFO - 2017-03-08 06:56:34 --> Utf8 Class Initialized
INFO - 2017-03-08 06:56:34 --> URI Class Initialized
INFO - 2017-03-08 06:56:34 --> Router Class Initialized
INFO - 2017-03-08 06:56:34 --> Output Class Initialized
INFO - 2017-03-08 06:56:34 --> Security Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 06:56:34 --> Input Class Initialized
INFO - 2017-03-08 06:56:34 --> Language Class Initialized
INFO - 2017-03-08 06:56:34 --> Loader Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Config file loaded: C:\xampp\htdocs\plastics\application\config/layout.php
INFO - 2017-03-08 06:56:34 --> Helper loaded: url_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: file_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: layout_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: form_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: date_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: common_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: breadcrumb_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: admin_helper
INFO - 2017-03-08 06:56:34 --> Helper loaded: shipping_helper
INFO - 2017-03-08 06:56:34 --> Database Driver Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-08 06:56:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-08 06:56:34 --> Pagination Class Initialized
INFO - 2017-03-08 06:56:34 --> Language file loaded: language/english/service_messages_lang.php
INFO - 2017-03-08 06:56:34 --> Controller Class Initialized
INFO - 2017-03-08 06:56:34 --> Form Validation Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Layout class already loaded. Second attempt ignored.
DEBUG - 2017-03-08 06:56:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-03-08 06:56:34 --> Model Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Pagination class already loaded. Second attempt ignored.
INFO - 2017-03-08 06:56:34 --> Encrypt Class Initialized
INFO - 2017-03-08 06:56:34 --> Parser Class Initialized
DEBUG - 2017-03-08 06:56:34 --> Listing class already loaded. Second attempt ignored.
INFO - 2017-03-08 06:56:34 --> Language file loaded: language/english/breadcrumb_lang.php
DEBUG - 2017-03-08 06:56:34 --> Config file loaded: C:\xampp\htdocs\plastics\application\config/breadcrumb.php
INFO - 2017-03-08 06:56:34 --> File loaded: C:\xampp\htdocs\plastics\application\views\frontend/dashboard/index.php
INFO - 2017-03-08 06:56:34 --> File loaded: C:\xampp\htdocs\plastics\application\views\_partials/header.php
INFO - 2017-03-08 06:56:34 --> File loaded: C:\xampp\htdocs\plastics\application\views\_partials/footer.php
INFO - 2017-03-08 06:56:34 --> File loaded: C:\xampp\htdocs\plastics\application\views\layouts/frontend.php
INFO - 2017-03-08 06:56:34 --> Final output sent to browser
DEBUG - 2017-03-08 06:56:34 --> Total execution time: 0.6387
