    </aside>
  </div>
</section>

<!--<footer id="footer-bar" class="row">
	<p id="footer-copyright" class="col-xs-12">
	Copyright &copy; – <script type="text/javascript">var year = new Date();document.write(year.getFullYear());</script>  IP System.
	</p>
</footer>
-->
