<script type="text/javascript">
$(function() {
	$("#data_table").zoomgrid({search_bar:true, sidebar:true});
	
});
</script>
